package main

// TODO: Write tests for func Run(args []string) error
// https://github.com/cosmos/cosmos-sdk/issues/11852
