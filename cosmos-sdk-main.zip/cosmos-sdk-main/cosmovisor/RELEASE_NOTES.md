# Cosmovisor v1.2.1 Release Notes

### Bug Fixes

* Fix failure when installing cosmovisor via `go install`.

### Changelog

For more details, please see the [CHANGELOG](https://github.com/cosmos/cosmos-sdk/blob/cosmovisor/v1.2.1/cosmovisor/CHANGELOG.md).
